var express=require("express");
var bodyParser = require("body-parser");

var app=express();
app.use(bodyParser.json());

var nodeadmin = require('nodeadmin');
app.use(nodeadmin(app));

//access static files
app.use(express.static('public'))
app.use('/nodeadmin', express.static('admin'))

app.use(express.json());       
app.use(express.urlencoded()); 

app.get('/proiectbd',function(req,res){
  res.status(200).send([]);
});

/* CANDIDATI*/
app.get('/proiectbd/Candidati/1', function(request, response) {
   Candidati.findAll().then(function(candidati){
        response.status(200).send(candidati)
    })        
})
app.get('/proiectbd/Candidati/1/:idCandidat', function(request, response) {
    Candidati.findOne({where: {idCandidat:request.params.idCandidat }}).then(function(candidati) {
        if(candidati) {
            response.status(200).send(candidati)
        } else {
            response.status(404).send()
        }
    })
})
app.post('/proiectbd/Candidati/1', function(request, response) {
    Candidati.create(request.body).then(function(candidati) {
        response.status(201).send(candidati)
    })
})

app.put('/proiectbd/Candidati/1/:idCandidati', function(request, response) {
    Candidati.findById(request.params. idCandidati).then(function(candidati) {
        if(candidati) {
            candidati.update(request.body).then(function(candidati){
                response.status(201).send(candidati)
            }).catch(function(error) {
                response.status(200).send(error)
            })
        } else {
            response.status(404).send('Not found')
        }
    })
})

app.delete('/proiectbd/Candidati/1/:idCandidat', function(request, response) {
    Candidati.findById(request.params.idCandidat).then(function(firma) {
        if(candidati) {
            candidati.destroy().then(function(){
                response.status(204).send()
            })
        } else {
            response.status(404).send('Not found')
        }
    })
})
/*JOBURI*/
app.get('/proiectbd/Joburi/1', function(request, response) {
   	Joburi.findAll().then(
            function(job) {
                response.status(200).send(job)
            }
        )
})

app.get('/proiectbd/Joburi/1/:idJob', function(request, response) {
    Joburi.findOne({where: {idJob:request.params.idJob}}).then(function(job) {
        if(job) {
            response.status(200).send(job)
        } else {
            response.status(404).send()
        }
    })
})

app.post('/proiectbd/Joburi/1', function(request, response) {
    Joburi.create(request.body).then(function(job) {
        response.status(201).send(job)
    })
})

app.put('/proiectbd/Joburi/1/:idJob', function(request, response) {
    Joburi.findById(request.params.idJob).then(function(job) {
        if(job) {
            job.update(request.body).then(function(job){
                response.status(201).send(job)
            }).catch(function(error) {
                response.status(200).send(error)
            })
        } else {
            response.status(404).send('Not found')
        }
    })
})

app.delete('/proiectbd/Joburi/1/:idJob', function(request, response) {
    Joburi.findById(request.params.idJob).then(function(job) {
        if(job) {
            job.destroy().then(function(){
                response.status(204).send()
            })
        } else {
            response.status(404).send('Not found')
        }
    })
})
app.listen(process.env.PORT);





/*var express=require("express");
var Sequelize = require("sequelize")
var bodyParser = require("body-parser");
var cors = require("cors");

var app=express();
app.use(bodyParser.json());
app.use(cors());

var nodeadmin = require('nodeadmin');
app.use(nodeadmin(app));

var sequelize = new Sequelize('proiect', 'root', '', {
   dialect:'mysql',
    host:'localhost'
})


/*var Candidati = sequelize.define('Candidati', {
   idCandidat: Sequelize.INTEGER
   Nume: Sequelize.STRING,
   Prenume: Sequelize.STRING,
   linkProfil:Sequelize.STRING
})

var Joburi = sequelize.define('Joburi', {
    idJob: Sequelize.INTEGER,
    denumire: Sequelize.STRING,
    domeniu: Sequelize.STRING,
    angajator: Sequelize.STRING
})
var CandidatiJoburi = sequelize.define('CandidatiJoburi', {
   idCandidat: Sequelize.INTEGER,
   idJob: Sequelize.INTEGER
})*/


/*app.get('/firme',function(req,res){
  res.status(200).send([]);
});

app.listen(process.env.PORT);*/
